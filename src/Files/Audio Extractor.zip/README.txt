Name: Pazera Free Audio Extractor (32/64 bit)
Version: 2.4
License: Freeware
Date: December 3, 2016
Author: Jacek Pazera
Web page: http://www.pazera-software.com/products/audio-extractor/
Quick start: http://www.pazera-software.com/products/audio-extractor/quickstart.php

////////////////////////////////////////////////////////////////////////////////

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  
////////////////////////////////////////////////////////////////////////////////