BCM v1.00

DESCRIPTION
BCM is a high-performance file compressor that utilizes advanced context modeling
techniques to achieve a very high compression ratio. All in all, it's like a big
brother of the BZIP2.

AUTHORS
Ilya Muravyov <ilya.muravyov@yahoo.com>
The libdivsufsort-lite library is developed by Yuta Mori <yuta.256@gmail.com>

THANKS
Special thanks to Yuta Mori, Matt Mahoney, Eugene Shelwien, Przemysław Skibiński
and LovePimple.

HOMEPAGE
http://sourceforge.net/projects/bcm/

